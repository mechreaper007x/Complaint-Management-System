package com.cms.controller;

import com.cms.model.Complaint;
import com.cms.service.ComplaintService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ComplaintPageController.class)
public class ComplaintPageControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ComplaintService complaintService;

    @Test
    void listComplaints() throws Exception {
        Complaint complaint = new Complaint();
        complaint.setId(1L);
        complaint.setTitle("Test Complaint");
        complaint.setDescription("Test Description");
        complaint.setCategory("IT");
        complaint.setStatus("OPEN");

        when(complaintService.listAllEntities()).thenReturn(List.of(complaint));

        mockMvc.perform(get("/complaints"))
                .andExpect(status().isOk())
                .andExpect(view().name("complaints"))
                .andExpect(model().attributeExists("complaints"));
    }

    @Test
    void showNewComplaintForm() throws Exception {
        mockMvc.perform(get("/complaints/new"))
                .andExpect(status().isOk())
                .andExpect(view().name("complaint-form"))
                .andExpect(model().attributeExists("complaint"));
    }

    @Test
    void listComplaintsWithFilters() throws Exception {
        Complaint c1 = new Complaint();
        c1.setId(1L);
        c1.setTitle("Test Complaint 1");
        c1.setDescription("Description 1");
        c1.setCategory("IT");
        c1.setStatus("OPEN");

        Complaint c2 = new Complaint();
        c2.setId(2L);
        c2.setTitle("Test Complaint 2");
        c2.setDescription("Description 2");
        c2.setCategory("Hostel");
        c2.setStatus("IN_PROGRESS");

        when(complaintService.listAllEntities()).thenReturn(List.of(c1, c2));

        mockMvc.perform(get("/complaints").param("status", "OPEN"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("complaints", hasSize(1)));

        mockMvc.perform(get("/complaints").param("category", "Hostel"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("complaints", hasSize(1)));

        mockMvc.perform(get("/complaints").param("q", "Complaint 1"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("complaints", hasSize(1)));
    }

    @Test
    void listComplaintsWithNoFilters() throws Exception {
        Complaint c1 = new Complaint();
        c1.setId(1L);
        c1.setTitle("Test Complaint 1");
        c1.setDescription("Description 1");
        c1.setCategory("IT");
        c1.setStatus("OPEN");

        when(complaintService.listAllEntities()).thenReturn(List.of(c1));

        mockMvc.perform(get("/complaints"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("complaints", hasSize(1)));
    }

    @Test
    void listComplaintsWithAllFilters() throws Exception {
        Complaint c1 = new Complaint();
        c1.setId(1L);
        c1.setTitle("Test Complaint 1");
        c1.setDescription("Description 1");
        c1.setCategory("IT");
        c1.setStatus("OPEN");

        when(complaintService.listAllEntities()).thenReturn(List.of(c1));

        mockMvc.perform(get("/complaints")
                        .param("status", "OPEN")
                        .param("category", "IT")
                        .param("q", "Test"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("complaints", hasSize(1)));
    }

    @Test
    void createComplaint() throws Exception {
        Complaint complaint = new Complaint();
        complaint.setId(1L);
        complaint.setTitle("New Complaint");
        complaint.setDescription("Description");
        complaint.setCategory("IT");
        complaint.setPriority("LOW");

        when(complaintService.create(any(Complaint.class))).thenReturn(complaint);

        mockMvc.perform(post("/complaints")
                        .param("title", "New Complaint")
                        .param("description", "Description")
                        .param("category", "IT")
                        .param("priority", "LOW"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/complaints"));
    }

    @Test
    void createComplaint_withErrors() throws Exception {
        mockMvc.perform(post("/complaints"))
                .andExpect(status().isOk())
                .andExpect(view().name("complaint-form"));
    }

    @Test
    void showComplaintDetail() throws Exception {
        Complaint complaint = new Complaint();
        complaint.setId(1L);
        complaint.setTitle("Test Complaint");

        when(complaintService.getEntity(1L)).thenReturn(complaint);

        mockMvc.perform(get("/complaints/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("complaint-detail"))
                .andExpect(model().attributeExists("complaint"));
    }

    @Test
    void transitionComplaintStatus() throws Exception {
        mockMvc.perform(post("/complaints/1/status")
                        .param("status", "IN_PROGRESS"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/complaints/1"));

        verify(complaintService, times(1)).transition(1L, "IN_PROGRESS", null);
    }

    @Test
    void deleteComplaint() throws Exception {
        mockMvc.perform(post("/complaints/1/delete"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/complaints"));

        verify(complaintService, times(1)).delete(1L);
    }
}
