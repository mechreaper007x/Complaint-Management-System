package com.cms.controller;

import com.cms.model.ComplaintDTO;
import com.cms.service.ComplaintService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

@WebMvcTest(ComplaintRestController.class)
public class ComplaintRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ComplaintService complaintService;

    @Test
    public void whenListComplaints_thenReturnComplaintsList() throws Exception {
        ComplaintDTO complaint = new ComplaintDTO();
        complaint.setId(1L);
        complaint.setTitle("Test Complaint");

        when(complaintService.listAll()).thenReturn(List.of(complaint));

        mockMvc.perform(get("/api/complaints"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].title", is("Test Complaint")));
    }

    @Test
    public void whenGetComplaint_thenReturnComplaint() throws Exception {
        ComplaintDTO complaint = new ComplaintDTO();
        complaint.setId(1L);
        complaint.setTitle("Test Complaint");

        when(complaintService.get(1L)).thenReturn(complaint);

        mockMvc.perform(get("/api/complaints/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title", is("Test Complaint")));
    }

    @Test
    public void whenCreateComplaint_thenReturnCreatedComplaint() throws Exception {
        ComplaintDTO complaint = new ComplaintDTO();
        complaint.setId(1L);
        complaint.setTitle("New Complaint");

        when(complaintService.create(any(ComplaintDTO.class))).thenReturn(complaint);

        mockMvc.perform(post("/api/complaints")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(complaint)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title", is("New Complaint")));
    }

    @Test
    public void whenUpdateComplaint_thenReturnUpdatedComplaint() throws Exception {
        ComplaintDTO complaint = new ComplaintDTO();
        complaint.setId(1L);
        complaint.setTitle("Updated Complaint");

        when(complaintService.update(eq(1L), any(ComplaintDTO.class))).thenReturn(complaint);

        mockMvc.perform(put("/api/complaints/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(complaint)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title", is("Updated Complaint")));
    }

    @Test
    public void whenUpdateStatus_thenReturnUpdatedComplaint() throws Exception {
        ComplaintDTO complaint = new ComplaintDTO();
        complaint.setId(1L);
        complaint.setStatus("IN_PROGRESS");

        when(complaintService.transition(1L, "IN_PROGRESS", "notes")).thenReturn(complaint);

        mockMvc.perform(patch("/api/complaints/1/status")
                        .param("status", "IN_PROGRESS")
                        .param("notes", "notes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status", is("IN_PROGRESS")));
    }

    @Test
    public void whenDeleteComplaint_thenStatusOk() throws Exception {
        doNothing().when(complaintService).delete(1L);
        mockMvc.perform(delete("/api/complaints/1"))
                .andExpect(status().isOk());
    }
}
