package com.cms.controller;

import com.cms.model.Complaint;
import com.cms.repository.ComplaintRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DashboardController.class)
public class DashboardControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ComplaintRepository complaintRepository;

    @Test
    public void whenHome_thenRedirectToDashboard() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"));
    }

    @Test
    public void whenDashboard_thenReturnDashboardView() throws Exception {
        Complaint c1 = Complaint.builder().status("OPEN").category("IT").build();
        Complaint c2 = Complaint.builder().status("OPEN").category("Hostel").build();
        Complaint c3 = Complaint.builder().status("RESOLVED").category("IT").build();
        List<Complaint> complaints = List.of(c1, c2, c3);

        when(complaintRepository.findAll()).thenReturn(complaints);

        mockMvc.perform(get("/dashboard"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(model().attributeExists("kpis", "statusCounts", "categoryCounts", "pageTitle"));
    }

    @Test
    public void whenDashboardWithNoComplaints_thenReturnDashboardView() throws Exception {
        when(complaintRepository.findAll()).thenReturn(new ArrayList<>());

        mockMvc.perform(get("/dashboard"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(model().attributeExists("kpis", "statusCounts", "categoryCounts"));
    }
}
