package com.cms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsApplicationTests {

	@Test
	void contextLoads() {
	}

    @Test
    void applicationContextMain() {
        CmsApplication.main(new String[]{});
    }

}
