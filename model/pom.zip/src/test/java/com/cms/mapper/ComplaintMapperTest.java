package com.cms.mapper;

import com.cms.model.Complaint;
import com.cms.model.ComplaintDTO;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class ComplaintMapperTest {

    private final ComplaintMapper mapper = ComplaintMapper.INSTANCE;

    @Test
    void testComplaintToComplaintDTO() {
        Complaint complaint = new Complaint();
        complaint.setId(1L);
        complaint.setTitle("Test Title");
        complaint.setDescription("Test Description");
        complaint.setCategory("IT");
        complaint.setPriority("HIGH");
        complaint.setStatus("OPEN");

        ComplaintDTO dto = mapper.complaintToComplaintDTO(complaint);

        assertEquals(complaint.getId(), dto.getId());
        assertEquals(complaint.getTitle(), dto.getTitle());
        assertEquals(complaint.getDescription(), dto.getDescription());
        assertEquals(complaint.getCategory(), dto.getCategory());
        assertEquals(complaint.getPriority(), dto.getPriority());
        assertEquals(complaint.getStatus(), dto.getStatus());
    }

    @Test
    void testComplaintDTOToComplaint() {
        ComplaintDTO dto = new ComplaintDTO();
        dto.setId(1L);
        dto.setTitle("Test Title");
        dto.setDescription("Test Description");
        dto.setCategory("IT");
        dto.setPriority("HIGH");
        dto.setStatus("OPEN");

        Complaint complaint = mapper.complaintDTOToComplaint(dto);

        assertEquals(dto.getId(), complaint.getId());
        assertEquals(dto.getTitle(), complaint.getTitle());
        assertEquals(dto.getDescription(), complaint.getDescription());
        assertEquals(dto.getCategory(), complaint.getCategory());
        assertEquals(dto.getPriority(), complaint.getPriority());
        assertEquals(dto.getStatus(), complaint.getStatus());
    }

    @Test
    void testComplaintToComplaintDTONull() {
        assertNull(mapper.complaintToComplaintDTO(null));
    }

    @Test
    void testComplaintDTOToComplaintNull() {
        assertNull(mapper.complaintDTOToComplaint(null));
    }
}
