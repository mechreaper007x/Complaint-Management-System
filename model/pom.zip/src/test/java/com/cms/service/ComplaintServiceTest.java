package com.cms.service;

import com.cms.mapper.ComplaintMapper;
import com.cms.model.Complaint;
import com.cms.model.ComplaintDTO;
import com.cms.repository.ComplaintRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ComplaintServiceTest {

    @Mock
    private ComplaintRepository complaintRepository;

    @Spy
    private ComplaintMapper complaintMapper = ComplaintMapper.INSTANCE;

    @InjectMocks
    private ComplaintService complaintService;

    private Complaint complaint;
    private ComplaintDTO complaintDTO;

    @BeforeEach
    void setUp() {
        complaint = new Complaint();
        complaint.setId(1L);
        complaint.setTitle("Test Complaint");
        complaint.setDescription("Test Description");
        complaint.setStatus("OPEN");
        complaint.setCategory("IT");
        complaint.setPriority("HIGH");

        complaintDTO = new ComplaintDTO();
        complaintDTO.setId(1L);
        complaintDTO.setTitle("Test Complaint");
        complaintDTO.setDescription("Test Description");
        complaintDTO.setStatus("OPEN");
        complaintDTO.setCategory("IT");
        complaintDTO.setPriority("HIGH");
    }

    @Test
    void listAll() {
        when(complaintRepository.findAllByOrderByCreatedAtDesc()).thenReturn(List.of(complaint));
        List<ComplaintDTO> result = complaintService.listAll();
        assertEquals(1, result.size());
        assertEquals(complaintDTO.getTitle(), result.get(0).getTitle());
        verify(complaintRepository).findAllByOrderByCreatedAtDesc();
    }

    @Test
    void listAllEntities() {
        when(complaintRepository.findAllByOrderByCreatedAtDesc()).thenReturn(List.of(complaint));
        List<Complaint> result = complaintService.listAllEntities();
        assertEquals(1, result.size());
        assertEquals(complaint.getTitle(), result.get(0).getTitle());
        verify(complaintRepository).findAllByOrderByCreatedAtDesc();
    }

    @Test
    void listByStatus() {
        when(complaintRepository.findByStatusOrderByCreatedAtDesc("OPEN")).thenReturn(List.of(complaint));
        List<ComplaintDTO> result = complaintService.listByStatus("OPEN");
        assertEquals(1, result.size());
        assertEquals("OPEN", result.get(0).getStatus());
        verify(complaintRepository).findByStatusOrderByCreatedAtDesc("OPEN");
    }

    @Test
    void getById() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.of(complaint));
        ComplaintDTO result = complaintService.get(1L);
        assertNotNull(result);
        assertEquals(complaint.getId(), result.getId());
        verify(complaintRepository).findById(1L);
    }

    @Test
    void getById_NotFound() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(Exception.class, () -> complaintService.get(1L));
    }

    @Test
    void getEntityById_NotFound() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(Exception.class, () -> complaintService.getEntity(1L));
    }

    @Test
    void createDto() {
        when(complaintRepository.save(any(Complaint.class))).thenReturn(complaint);
        ComplaintDTO result = complaintService.create(complaintDTO);
        assertNotNull(result);
        assertEquals(complaintDTO.getId(), result.getId());
        verify(complaintRepository).save(any(Complaint.class));
    }

    @Test
    void createEntity() {
        when(complaintRepository.save(any(Complaint.class))).thenReturn(complaint);
        Complaint result = complaintService.create(complaint);
        assertNotNull(result);
        assertEquals(complaint.getId(), result.getId());
        verify(complaintRepository).save(any(Complaint.class));
    }

    @Test
    void update() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.of(complaint));
        when(complaintRepository.save(any(Complaint.class))).thenReturn(complaint);

        ComplaintDTO updatedDto = new ComplaintDTO();
        updatedDto.setTitle("Updated Title");
        updatedDto.setDescription("Updated Description");

        ComplaintDTO result = complaintService.update(1L, updatedDto);

        assertNotNull(result);
        assertEquals("Updated Title", result.getTitle());
        verify(complaintRepository).findById(1L);
        verify(complaintRepository).save(any(Complaint.class));
    }
    
    @Test
    void update_NotFound() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(Exception.class, () -> complaintService.update(1L, complaintDTO));
    }

    @Test
    void transition() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.of(complaint));
        when(complaintRepository.save(any(Complaint.class))).thenReturn(complaint);

        ComplaintDTO result = complaintService.transition(1L, "IN_PROGRESS", "Work in progress");

        assertNotNull(result);
        assertEquals("IN_PROGRESS", result.getStatus());
        verify(complaintRepository).findById(1L);
        verify(complaintRepository).save(any(Complaint.class));
    }
    
    @Test
    void transition_NotFound() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(Exception.class, () -> complaintService.transition(1L, "IN_PROGRESS", "notes"));
    }

    @Test
    void transition_withNullNotes() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.of(complaint));
        when(complaintRepository.save(any(Complaint.class))).thenReturn(complaint);

        ComplaintDTO result = complaintService.transition(1L, "IN_PROGRESS", null);

        assertNotNull(result);
        assertEquals("IN_PROGRESS", result.getStatus());
        verify(complaintRepository).findById(1L);
        verify(complaintRepository).save(any(Complaint.class));
    }

    @Test
    void delete() {
        doNothing().when(complaintRepository).deleteById(1L);
        complaintService.delete(1L);
        verify(complaintRepository, times(1)).deleteById(1L);
    }
}
