package com.cms.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ComplaintTest {

  private Complaint complaint1;
  private Complaint complaint2;

  @BeforeEach
  void setUp() {
    complaint1 =
        Complaint.builder()
            .id(1L)
            .title("Test Title")
            .description("Test Description")
            .category("BUG")
            .priority("HIGH")
            .reporterName("John Doe")
            .reporterEmail("john.doe@example.com")
            .reporterPhone("1234567890")
            .resolutionNotes("Fixed.")
            .build();

    complaint2 =
        Complaint.builder()
            .id(1L)
            .title("Test Title")
            .description("Test Description")
            .category("BUG")
            .priority("HIGH")
            .reporterName("John Doe")
            .reporterEmail("john.doe@example.com")
            .reporterPhone("1234567890")
            .resolutionNotes("Fixed.")
            .build();
  }

  @Test
  void testComplaintCreationAndGetters() {
    assertNotNull(complaint1);
    assertEquals(1L, complaint1.getId());
    assertEquals("Test Title", complaint1.getTitle());
    assertEquals("Test Description", complaint1.getDescription());
    assertEquals("BUG", complaint1.getCategory());
    assertEquals("HIGH", complaint1.getPriority());
    assertEquals("OPEN", complaint1.getStatus()); // Default value
    assertEquals("John Doe", complaint1.getReporterName());
    assertEquals("john.doe@example.com", complaint1.getReporterEmail());
    assertEquals("1234567890", complaint1.getReporterPhone());
    assertEquals("Fixed.", complaint1.getResolutionNotes());
    assertNotNull(complaint1.getCreatedAt());
    assertNotNull(complaint1.getUpdatedAt());
  }

  @Test
  void testSetters() {
    Complaint complaint = new Complaint();
    complaint.setId(2L);
    complaint.setTitle("New Title");
    complaint.setDescription("New Description");
    complaint.setCategory("FEATURE");
    complaint.setPriority("LOW");
    complaint.setStatus("CLOSED");
    complaint.setReporterName("Jane Doe");
    complaint.setReporterEmail("jane.doe@example.com");
    complaint.setReporterPhone("0987654321");
    complaint.setResolutionNotes("Implemented.");
    LocalDateTime now = LocalDateTime.now();
    complaint.setCreatedAt(now);
    complaint.setUpdatedAt(now);

    assertEquals(2L, complaint.getId());
    assertEquals("New Title", complaint.getTitle());
    assertEquals("New Description", complaint.getDescription());
    assertEquals("FEATURE", complaint.getCategory());
    assertEquals("LOW", complaint.getPriority());
    assertEquals("CLOSED", complaint.getStatus());
    assertEquals("Jane Doe", complaint.getReporterName());
    assertEquals("jane.doe@example.com", complaint.getReporterEmail());
    assertEquals("0987654321", complaint.getReporterPhone());
    assertEquals("Implemented.", complaint.getResolutionNotes());
    assertEquals(now, complaint.getCreatedAt());
    assertEquals(now, complaint.getUpdatedAt());
  }

  @Test
  void testEqualsAndHashCode() {
    assertEquals(complaint1, complaint2);
    assertEquals(complaint1.hashCode(), complaint2.hashCode());

    complaint2.setId(2L);
    assertNotEquals(complaint1, complaint2);
    assertNotEquals(complaint1.hashCode(), complaint2.hashCode());
  }

  @Test
  void testToString() {
    String complaintString = complaint1.toString();
    assertTrue(complaintString.contains("id=1"));
    assertTrue(complaintString.contains("title=Test Title"));
  }

  @Test
  void testPreUpdate() {
    LocalDateTime initialUpdatedAt = complaint1.getUpdatedAt();
    // Simulate a delay
    try {
      Thread.sleep(10);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
    complaint1.onUpdate();
    LocalDateTime newUpdatedAt = complaint1.getUpdatedAt();
    assertNotEquals(initialUpdatedAt, newUpdatedAt);
  }

  @Test
  void testDefaultValues() {
    Complaint complaint = Complaint.builder().title("Minimal").description("Desc").category("Cat").priority("Pri").build();
    assertEquals("OPEN", complaint.getStatus());
    assertNotNull(complaint.getCreatedAt());
    assertNotNull(complaint.getUpdatedAt());
  }

  @Test
  void testNoArgsConstructor() {
    Complaint complaint = new Complaint();
    assertNotNull(complaint);
  }
}