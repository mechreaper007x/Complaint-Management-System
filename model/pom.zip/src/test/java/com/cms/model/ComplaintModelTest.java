package com.cms.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ComplaintDTOTest {

  private ComplaintDTO dto1;
  private ComplaintDTO dto2;

  @BeforeEach
  void setUp() {
    dto1 = new ComplaintDTO();
    dto1.setId(1L);
    dto1.setTitle("Test DTO");
    dto1.setDescription("DTO Description");
    dto1.setCategory("BUG");
    dto1.setPriority("HIGH");
    dto1.setStatus("OPEN");
    dto1.setReporterName("John Doe");
    dto1.setReporterEmail("john.doe@example.com");
    dto1.setReporterPhone("1234567890");
    dto1.setResolutionNotes("Pending");
    dto1.setCreatedAt(LocalDateTime.now());
    dto1.setUpdatedAt(LocalDateTime.now());

    dto2 = new ComplaintDTO();
    dto2.setId(1L);
    dto2.setTitle("Test DTO");
    dto2.setDescription("DTO Description");
    dto2.setCategory("BUG");
    dto2.setPriority("HIGH");
    dto2.setStatus("OPEN");
    dto2.setReporterName("John Doe");
    dto2.setReporterEmail("john.doe@example.com");
    dto2.setReporterPhone("1234567890");
    dto2.setResolutionNotes("Pending");
    dto2.setCreatedAt(dto1.getCreatedAt());
    dto2.setUpdatedAt(dto1.getUpdatedAt());
  }

  @Test
  void testGettersAndSetters() {
    ComplaintDTO dto = new ComplaintDTO();
    LocalDateTime now = LocalDateTime.now();

    dto.setId(2L);
    dto.setTitle("New DTO");
    dto.setDescription("New Description");
    dto.setCategory("FEATURE");
    dto.setPriority("LOW");
    dto.setStatus("CLOSED");
    dto.setReporterName("Jane Doe");
    dto.setReporterEmail("jane.doe@example.com");
    dto.setReporterPhone("0987654321");
    dto.setResolutionNotes("Done");
    dto.setCreatedAt(now);
    dto.setUpdatedAt(now);

    assertEquals(2L, dto.getId());
    assertEquals("New DTO", dto.getTitle());
    assertEquals("New Description", dto.getDescription());
    assertEquals("FEATURE", dto.getCategory());
    assertEquals("LOW", dto.getPriority());
    assertEquals("CLOSED", dto.getStatus());
    assertEquals("Jane Doe", dto.getReporterName());
    assertEquals("jane.doe@example.com", dto.getReporterEmail());
    assertEquals("0987654321", dto.getReporterPhone());
    assertEquals("Done", dto.getResolutionNotes());
    assertEquals(now, dto.getCreatedAt());
    assertEquals(now, dto.getUpdatedAt());
  }

  @Test
  void testEqualsAndHashCode() {
    assertEquals(dto1, dto2);
    assertEquals(dto1.hashCode(), dto2.hashCode());

    dto2.setId(3L);
    assertNotEquals(dto1, dto2);
    assertNotEquals(dto1.hashCode(), dto2.hashCode());
  }

  @Test
  void testToString() {
    String dtoString = dto1.toString();
    assertNotNull(dtoString);
    assertTrue(dtoString.contains("id=1"));
    assertTrue(dtoString.contains("title=Test DTO"));
  }

  @Test
  void testNoArgsConstructor() {
    ComplaintDTO dto = new ComplaintDTO();
    assertNotNull(dto);
  }
}