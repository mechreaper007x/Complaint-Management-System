package com.cms.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cms.model.ComplaintDTO;
import com.cms.service.ComplaintService;

@RestController
@RequestMapping("/api/complaints")
public class ComplaintRestController {
  private final ComplaintService service;

  public ComplaintRestController(ComplaintService service) {
    this.service = service;
  }

  @GetMapping
  public List<ComplaintDTO> list() {
    return service.listAll();
  }

  @GetMapping("/{id}")
  public ComplaintDTO get(@PathVariable Long id) {
    return service.get(id);
  }

  @PostMapping
  public ComplaintDTO create(@RequestBody ComplaintDTO c) {
    return service.create(c);
  }

  @PutMapping("/{id}")
  public ComplaintDTO update(@PathVariable Long id, @RequestBody ComplaintDTO c) {
    return service.update(id, c);
  }

  @PatchMapping("/{id}/status")
  public ComplaintDTO updateStatus(@PathVariable Long id,
                                @RequestParam String status,
                                @RequestParam(required = false) String notes) {
    return service.transition(id, status, notes);
  }

  @DeleteMapping("/{id}")
  public void delete(@PathVariable Long id) {
    service.delete(id);
  }
}

