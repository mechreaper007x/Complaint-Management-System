package com.cms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cms.mapper.ComplaintMapper;
import com.cms.model.Complaint;
import com.cms.model.ComplaintDTO;
import com.cms.repository.ComplaintRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComplaintService {
  private final ComplaintRepository repo;
  private final ComplaintMapper mapper = ComplaintMapper.INSTANCE;

  public List<ComplaintDTO> listAll(){ return repo.findAllByOrderByCreatedAtDesc().stream().map(mapper::complaintToComplaintDTO).toList(); }
  
  public List<Complaint> listAllEntities(){ return repo.findAllByOrderByCreatedAtDesc(); }

  public List<ComplaintDTO> listByStatus(String status){ return repo.findByStatusOrderByCreatedAtDesc(status).stream().map(mapper::complaintToComplaintDTO).toList(); }
  
  public ComplaintDTO get(Long id){ return repo.findById(id).map(mapper::complaintToComplaintDTO).orElseThrow(); }
  
  public Complaint getEntity(Long id){ return repo.findById(id).orElseThrow(); }

  public ComplaintDTO create(ComplaintDTO c){ 
    Complaint complaint = mapper.complaintDTOToComplaint(c);
    return mapper.complaintToComplaintDTO(repo.save(complaint)); 
  }

  public Complaint create(Complaint c){ 
    return repo.save(c);
  }

  public ComplaintDTO update(Long id, ComplaintDTO c){
    Complaint existing = repo.findById(id).orElseThrow();
    if (c.getTitle() != null) existing.setTitle(c.getTitle());
    if (c.getDescription() != null) existing.setDescription(c.getDescription());
    if (c.getCategory() != null) existing.setCategory(c.getCategory());
    if (c.getPriority() != null) existing.setPriority(c.getPriority());
    if (c.getStatus() != null) existing.setStatus(c.getStatus());
    return mapper.complaintToComplaintDTO(repo.save(existing));
  }

  public ComplaintDTO transition(Long id, String status, String notes){
    Complaint c = repo.findById(id).orElseThrow();
    c.setStatus(status);
    if (notes != null && !notes.isBlank()) c.setResolutionNotes(notes);
    return mapper.complaintToComplaintDTO(repo.save(c));
  }
  
  public void delete(Long id){ repo.deleteById(id); }
}
